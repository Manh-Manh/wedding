import { Component, ChangeDetectionStrategy, inject, signal, OnDestroy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ConfigService } from '../../services/config.service';
import { SafeUrlPipe } from '../../pipes/safe-url.pipe';
import { FadeInDirective } from '../../directives/fade-in.directive';
import { LightboxComponent } from '../shared/lightbox/lightbox.component';

@Component({
  selector: 'app-template-eight',
  standalone: true,
  imports: [CommonModule, RouterLink, SafeUrlPipe, FadeInDirective, LightboxComponent],
  templateUrl: './template-eight.component.html',
  styleUrls: ['./template-eight.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TemplateEightComponent implements OnDestroy {
  private configService = inject(ConfigService);
  config = this.configService.config;
  templateKey = 'template-8';
  templateInfo = computed(() => this.config().templates[this.templateKey]);
  
  timeLeft = signal({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  private intervalId?: number;

  // Gallery and Lightbox state
  galleryCategories = computed(() => Object.keys(this.config().galleryImages));
  
  private userSelectedCategory = signal<string | null>(null);

  activeCategory = computed(() => {
    const categories = this.galleryCategories();
    if (!categories || categories.length === 0) {
      return null;
    }
    const userSelection = this.userSelectedCategory();
    if (userSelection && categories.includes(userSelection)) {
      return userSelection;
    }
    return categories[0];
  });

  activeImages = computed(() => {
    const category = this.activeCategory();
    const gallery = this.config().galleryImages;
    if (!category || !gallery || !gallery[category]) {
      return [];
    }
    const images = gallery[category];
    return Array.isArray(images) ? images : [];
  });
  
  selectedImageIndex = signal<number | null>(null);
  isLightboxOpen = computed(() => this.selectedImageIndex() !== null);
  selectedImageUrl = computed(() => {
    const index = this.selectedImageIndex();
    const images = this.activeImages();
    if (index === null || !Array.isArray(images) || images.length === 0) return null;
    return images[index] || null;
  });

  constructor() {
    this.startCountdown();
  }

  startCountdown() {
    const weddingDate = new Date(this.config().mainEvent.date).getTime();

    this.intervalId = window.setInterval(() => {
      const now = new Date().getTime();
      const distance = weddingDate - now;

      if (distance < 0) {
        this.timeLeft.set({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (this.intervalId) clearInterval(this.intervalId);
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      this.timeLeft.set({ days, hours, minutes, seconds });
    }, 1000);
  }

  ngOnDestroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  getFormattedDate(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  getFormattedTime(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute:'2-digit' });
  }

  formatStoryDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  // Gallery Methods
  selectCategory(category: string): void {
    this.userSelectedCategory.set(category);
  }

  // Lightbox methods
  openLightbox(index: number): void {
    this.selectedImageIndex.set(index);
  }

  closeLightbox(): void {
    this.selectedImageIndex.set(null);
  }

  nextImage(): void {
    if (this.selectedImageIndex() !== null) {
      const nextIndex = (this.selectedImageIndex()! + 1) % this.activeImages().length;
      this.selectedImageIndex.set(nextIndex);
    }
  }

  prevImage(): void {
    if (this.selectedImageIndex() !== null) {
      const prevIndex = (this.selectedImageIndex()! - 1 + this.activeImages().length) % this.activeImages().length;
      this.selectedImageIndex.set(prevIndex);
    }
  }
}