import { Component, ChangeDetectionStrategy, input, output, HostListener, effect, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-lightbox',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lightbox.component.html',
  styleUrls: ['./lightbox.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LightboxComponent {
  imageUrl = input.required<string>();
  onClose = output<void>();
  onNext = output<void>();
  onPrev = output<void>();

  showControls = signal(true);
  private timeoutId?: number;

  constructor() {
    effect(() => {
      // When the imageUrl changes, reset the controls visibility
      this.imageUrl(); // dependency
      this.resetControlsTimeout();
    });
  }

  @HostListener('document:keydown.escape', ['$event'])
  onEscapeKey(event: KeyboardEvent) {
    this.onClose.emit();
  }

  @HostListener('document:keydown.arrowright', ['$event'])
  onArrowRight(event: KeyboardEvent) {
    this.onNext.emit();
  }
  
  @HostListener('document:keydown.arrowleft', ['$event'])
  onArrowLeft(event: KeyboardEvent) {
    this.onPrev.emit();
  }

  @HostListener('mousemove')
  onMouseMove() {
    this.showControls.set(true);
    this.resetControlsTimeout();
  }

  close() {
    this.onClose.emit();
  }

  private resetControlsTimeout() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
    this.timeoutId = window.setTimeout(() => this.showControls.set(false), 3000);
  }
}
