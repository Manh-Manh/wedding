import { WeddingConfig } from '../models/config.model';

export const weddingConfig: WeddingConfig = {
  couple: {
    groom: {
      name: 'Đình Mạnh',
      description: 'The happiest man on Earth.',
      image: 'https://i.pinimg.com/564x/01/f9/be/01f9be244a2c416196a603c623a3d548.jpg',
      parents: 'Mr. Nguyễn Văn A & Mrs. Trần Thị B',
      homeLocation: {
        name: "Groom's Residence",
        mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.631024925016!2d105.8222163148829!3d21.0073849860099!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac8113262b95%3A0x7d94411135a8289a!2sRoyal%20City!5e0!3m2!1sen!2s!4v1628886981240!5m2!1sen!2s',
      },
    },
    bride: {
      name: 'Thị Hường',
      description: 'The luckiest woman in the world.',
      image: 'https://i.pinimg.com/564x/e3/37/10/e337107292a833b3a3721ddf1e00344d.jpg',
      parents: 'Mr. Trần Văn C & Mrs. Lê Thị D',
      homeLocation: {
        name: "Bride's Residence",
        mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.098416042456!2d105.78311181488313!3d21.02809598600001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab88535031d3%3A0x35624e5485b46e3a!2sKeangnam%20Hanoi%20Landmark%20Tower!5e0!3m2!1sen!2s!4v1628887038753!5m2!1sen!2s',
      },
    },
  },
  mainEvent: {
    name: 'Wedding Ceremony & Reception',
    date: '2025-11-15T10:00:00',
    venue: 'Trống Đồng Palace',
    address: '22 P. Thành Công, Thành Công, Ba Đình, Hà Nội',
    mapUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.357494458992!2d105.81745421533869!3d21.01859608600466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab725893d56d%3A0x33b8a6a6839b28a2!2zVHLhu5FuZyDEkOG7k25nIFBhbGFjZQ!5e0!3m2!1sen!2s!4v1676451392687!5m2!1sen!2s'
  },
  loveStory: {
    title: 'Our Love Story',
    milestones: [
      {
        date: '2022-04-10',
        image: 'https://picsum.photos/id/1015/800/600',
        content: 'It all started on a rainy Tuesday at a small coffee shop. Neither of us expected that a simple conversation would be the beginning of our forever.'
      },
      {
        date: '2023-08-22',
        image: 'https://picsum.photos/id/1016/800/600',
        content: 'From coffee dates to traveling the world, every moment has been an adventure. We have grown together, supported each other\'s dreams, and built a love that is stronger than we could have ever imagined.'
      },
      {
        date: '2024-12-25',
        image: 'https://picsum.photos/id/1018/800/600',
        content: 'Now, we are taking the next step and starting our new chapter as husband and wife. We are so excited to celebrate our love with you, our dearest friends and family.'
      }
    ]
  },
  galleryImages: {
    Wedding: [
      'https://picsum.photos/id/10/800/600',
      'https://picsum.photos/id/20/800/600',
      'https://picsum.photos/id/30/600/800',
      'https://picsum.photos/id/40/800/600',
      'https://picsum.photos/id/50/600/800',
      'https://picsum.photos/id/60/800/600',
    ],
    Daily: [
      'https://picsum.photos/id/70/800/600',
      'https://picsum.photos/id/80/600/800',
      'https://picsum.photos/id/90/800/800',
      'https://picsum.photos/id/100/600/800'
    ]
  },
  templates: {
    'template-1': {
        name: 'Classic Elegance',
        description: 'A timeless design with a touch of modern sophistication.',
        heroImage: 'https://images.unsplash.com/photo-1523438097201-512ae7d59c44?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1523438097201-512ae7d59c44?q=80&w=400&auto=format&fit=crop',
    },
    'template-2': {
        name: 'Modern Minimalist',
        description: 'Clean lines and a focus on beautiful typography.',
        heroImage: 'https://images.unsplash.com/photo-1457439067824-c1787c934333?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1457439067824-c1787c934333?q=80&w=400&auto=format&fit=crop',
    },
    'template-3': {
        name: 'Romantic Garden',
        description: 'A dreamy and whimsical theme with floral accents.',
        heroImage: 'https://images.unsplash.com/photo-1542042161-d10f8a84d872?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1542042161-d10f8a84d872?q=80&w=400&auto=format&fit=crop',
    },
    'template-4': {
      name: 'Celestial Starry Night',
      description: 'A magical and romantic theme under a starlit sky.',
      heroImage: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=1920&auto=format&fit=crop',
      previewImage: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=400&auto=format&fit=crop',
    },
    'template-5': {
        name: 'Vintage Art Deco',
        description: 'Sophisticated and glamorous with a touch of the roaring twenties.',
        heroImage: 'https://images.unsplash.com/photo-1617594225321-c1b0331a3969?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1617594225321-c1b0331a3969?q=80&w=400&auto=format&fit=crop',
    },
    'template-6': {
        name: 'Tropical Beach',
        description: 'A fresh and breezy design for a destination wedding feel.',
        heroImage: 'https://images.unsplash.com/photo-1507525428034-b723a996f6ea?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1507525428034-b723a996f6ea?q=80&w=400&auto=format&fit=crop',
    },
    'template-7': {
        name: 'Artistic Watercolor',
        description: 'A soft, personal, and artful theme with painterly touches.',
        heroImage: 'https://images.unsplash.com/photo-1567095761054-7a02e69e5c43?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1567095761054-7a02e69e5c43?q=80&w=400&auto=format&fit=crop',
    },
    'template-8': {
        name: 'Enchanted Forest',
        description: 'A whimsical and magical theme set in a fairytale forest.',
        heroImage: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1920&auto=format&fit=crop',
        previewImage: 'https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=400&auto=format&fit=crop',
    }
  },
  receptionDetails: {
    backgroundImg: 'https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?q=80&w=1920&auto=format&fit=crop'
  },
  thankYou: {
    title: 'Thank You',
    message: 'Thank you for being a part of our special day and for your love and support. It means the world to us to have you celebrate with us as we begin our new journey together.'
  },
  footer: {
    authorName: 'AI Studio Developer',
    authorLink: '#'
  }
};