import { Injectable, signal, computed } from '@angular/core';
import { weddingConfig } from '../config/wedding.config';
import { WeddingConfig } from '../models/config.model';

interface ConfigState {
  config: WeddingConfig;
  loading: boolean;
  error: any;
}

@Injectable({
  providedIn: 'root',
})
export class ConfigService {
  private state = signal<ConfigState>({
    config: weddingConfig, // Start with default config
    loading: true,
    error: null
  });

  // Public readonly signals
  public readonly config = computed(() => this.state().config);
  public readonly isLoading = computed(() => this.state().loading);
  public readonly error = computed(() => this.state().error);

  constructor() {
    this.fetchConfig();
  }

  private fetchConfig() {
    this.state.update(value => ({ ...value, loading: true }));

    // Simulate an API call
    setTimeout(() => {
      try {
        // In a real app, you would fetch from an API:
        // const fetchedConfig = await fetch('/api/config').then(res => res.json());
        // For now, we'll just use the local config successfully.
        const fetchedConfig = weddingConfig; 

        this.state.set({
          config: fetchedConfig,
          loading: false,
          error: null
        });
      } catch (e) {
        console.error("Failed to fetch remote config, using default.", e);
        this.state.update(value => ({
            ...value,
            loading: false,
            error: e
        }));
      }
    }, 1500); // Simulate 1.5 second network delay
  }
}