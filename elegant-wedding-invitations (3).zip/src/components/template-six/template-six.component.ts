import { Component, ChangeDetectionStrategy, inject, signal, OnDestroy, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ConfigService } from '../../services/config.service';
import { GuestbookService } from '../../services/guestbook.service';
import { SafeUrlPipe } from '../../pipes/safe-url.pipe';
import { FadeInDirective } from '../../directives/fade-in.directive';
import { LightboxComponent } from '../shared/lightbox/lightbox.component';
import { MiniGameComponent } from '../shared/mini-game/mini-game.component';

@Component({
  selector: 'app-template-six',
  imports: [CommonModule, RouterLink, ReactiveFormsModule, SafeUrlPipe, FadeInDirective, LightboxComponent, MiniGameComponent],
  templateUrl: './template-six.component.html',
  styleUrls: ['./template-six.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TemplateSixComponent implements OnDestroy {
  private configService = inject(ConfigService);
  private guestbookService = inject(GuestbookService);
  // FIX: Explicitly type FormBuilder to fix type inference issue.
  private fb: FormBuilder = inject(FormBuilder);
  
  config = this.configService.config;
  templateKey = 'template-6';
  templateInfo = computed(() => this.config().templates[this.templateKey]);
  
  timeLeft = signal({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  private intervalId?: number;

  // Gifting state
  copiedGroom = signal(false);
  copiedBride = signal(false);

  // Guestbook state
  guestbookMessages = this.guestbookService.messages;
  guestbookForm = this.fb.group({
    name: ['', Validators.required],
    message: ['', Validators.required],
  });

  // Gallery and Lightbox state
  galleryCategories = computed(() => Object.keys(this.config().galleryImages));
  
  private userSelectedCategory = signal<string | null>(null);

  activeCategory = computed(() => {
    const categories = this.galleryCategories();
    if (!categories || categories.length === 0) return null;
    const userSelection = this.userSelectedCategory();
    return (userSelection && categories.includes(userSelection)) ? userSelection : categories[0];
  });

  activeImages = computed(() => {
    const category = this.activeCategory();
    const gallery = this.config().galleryImages;
    const images = category ? gallery[category] : [];
    return Array.isArray(images) ? images : [];
  });
  
  selectedImageIndex = signal<number | null>(null);
  isLightboxOpen = computed(() => this.selectedImageIndex() !== null);
  selectedImageUrl = computed(() => {
    const index = this.selectedImageIndex();
    const images = this.activeImages();
    if (index === null || !images) return null;
    return images[index] || null;
  });

  constructor() {
    this.startCountdown();
  }

  startCountdown() {
    const weddingDate = new Date(this.config().mainEvent.date).getTime();
    this.intervalId = window.setInterval(() => {
      const now = new Date().getTime();
      const distance = weddingDate - now;

      if (distance < 0) {
        this.timeLeft.set({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (this.intervalId) clearInterval(this.intervalId);
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      this.timeLeft.set({ days, hours, minutes, seconds });
    }, 1000);
  }

  ngOnDestroy() {
    if (this.intervalId) clearInterval(this.intervalId);
  }

  getFormattedDate(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  }

  getFormattedTime(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute:'2-digit' });
  }

  formatStoryDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  }

  async copyToClipboard(accountNumber: string, type: 'groom' | 'bride') {
    try {
      await navigator.clipboard.writeText(accountNumber);
      if (type === 'groom') {
        this.copiedGroom.set(true);
        setTimeout(() => this.copiedGroom.set(false), 2000);
      } else {
        this.copiedBride.set(true);
        setTimeout(() => this.copiedBride.set(false), 2000);
      }
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  }

  submitGuestbookMessage() {
    if (this.guestbookForm.valid) {
      const { name, message } = this.guestbookForm.value;
      this.guestbookService.addMessage(name!, message!);
      this.guestbookForm.reset();
    }
  }

  selectCategory(category: string): void {
    this.userSelectedCategory.set(category);
  }

  openLightbox(index: number): void {
    this.selectedImageIndex.set(index);
  }

  closeLightbox(): void {
    this.selectedImageIndex.set(null);
  }

  nextImage(): void {
    if (this.selectedImageIndex() !== null) {
      this.selectedImageIndex.update(index => (index! + 1) % this.activeImages().length);
    }
  }

  prevImage(): void {
    if (this.selectedImageIndex() !== null) {
      this.selectedImageIndex.update(index => (index! - 1 + this.activeImages().length) % this.activeImages().length);
    }
  }
}