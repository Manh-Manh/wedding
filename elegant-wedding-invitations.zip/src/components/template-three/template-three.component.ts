import { Component, ChangeDetectionStrategy, inject, computed, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ConfigService } from '../../services/config.service';
import { SafeUrlPipe } from '../../pipes/safe-url.pipe';

@Component({
  selector: 'app-template-three',
  standalone: true,
  imports: [CommonModule, RouterLink, SafeUrlPipe],
  templateUrl: './template-three.component.html',
  styleUrls: ['./template-three.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TemplateThreeComponent implements OnDestroy {
  private configService = inject(ConfigService);
  config = this.configService.getConfig();
  templateKey = 'template-3';
  templateInfo = computed(() => this.config().templates[this.templateKey]);
  
  timeLeft = signal({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  private intervalId?: number;

  constructor() {
    this.startCountdown();
  }

  startCountdown() {
    const weddingDate = new Date(this.config().mainEvent.date).getTime();

    this.intervalId = window.setInterval(() => {
      const now = new Date().getTime();
      const distance = weddingDate - now;

      if (distance < 0) {
        this.timeLeft.set({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (this.intervalId) clearInterval(this.intervalId);
        return;
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);

      this.timeLeft.set({ days, hours, minutes, seconds });
    }, 1000);
  }

  ngOnDestroy() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  getFormattedDate(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  }

  getFormattedTime(): string {
    const date = new Date(this.config().mainEvent.date);
    return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  }

  formatStoryDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }
}