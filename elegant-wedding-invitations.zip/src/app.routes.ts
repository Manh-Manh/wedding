import { Routes } from '@angular/router';

export const APP_ROUTES: Routes = [
  {
    path: 'home',
    loadComponent: () =>
      import('./components/home/home.component').then((m) => m.HomeComponent),
  },
  {
    path: 'template-1',
    loadComponent: () =>
      import('./components/template-one/template-one.component').then(
        (m) => m.TemplateOneComponent
      ),
  },
  {
    path: 'template-2',
    loadComponent: () =>
      import('./components/template-two/template-two.component').then(
        (m) => m.TemplateTwoComponent
      ),
  },
  {
    path: 'template-3',
    loadComponent: () =>
      import('./components/template-three/template-three.component').then(
        (m) => m.TemplateThreeComponent
      ),
  },
  {
    path: '**',
    redirectTo: 'home',
    pathMatch: 'full',
  },
];
