import { Injectable, signal } from '@angular/core';
import { weddingConfig } from '../config/wedding.config';
import { WeddingConfig } from '../models/config.model';

@Injectable({
  providedIn: 'root',
})
export class ConfigService {
  private config = signal<WeddingConfig>(weddingConfig);

  getConfig() {
    return this.config.asReadonly();
  }
}
